## Whether to allow the user to run the notebook as root.
c.ServerApp.allow_root = True
c.ServerApp.ip = "*"
c.ServerApp.port = 8888
c.ServerApp.token = ""
c.ServerApp.disable_check_xsrf = True
c.ServerApp.allow_origin = "*"
